Dado("que estou no formulario de cadastro") do
    visit 'https://www.americanas.com.br'
  end
  
Dado("passo os seguintes dados:") do |table|
    @usuario = table.rows_hash
end
  
Quando("faco o cadastro") do
    #Encontrar componente para cadastro do novo cliente
    find('#h_user').click

    #Clicar no link "Cadastre-se"
    find('.usr-signup').click

    #Preencher o formulário com as informações obrigatórias
    find('#email-input').set @usuario[:email]
    find('#password-input').set @usuario[:senha]
    find('#cpf-input').set @usuario[:cpf]
    find('#name-input').set @usuario[:nome]
    find('#birthday-input').set @usuario[:dtaNascimento]
    if(@usuario[:sexo] == 'M') then
        find("label[for='gender_M']").click
        sleep 5
    else
        find("label[for='gender_F']").click
        sleep (5)
    end
    find('#phone-input').set @usuario[:telefone]
    
    #Clicar no botão "Criar seu Cadastro"
    find('button[type=submit]').click
end

Entao("vejo a ProgressBar de forca de senha com a mensagem {string}") do |mensagem_barra|
    seguranca_senha = find('.passwordWrapper-msg')
    expect(seguranca_senha.text).to eql mensagem_barra
end

Entao("vejo a mensagem {string}") do |mensagem_alerta|                                 
     mensagem_validacao = find('.inputGroup-error ')
     expect(mensagem_validacao.text).to eql mensagem_alerta
end                                                                              
 
Entao("vejo a mensagem de boas vindas {string}") do |ola_usuario|
    mensagem_login = find('.loggedin ready')
    expect(mensagem_login.text).to eql ola_usuario
end